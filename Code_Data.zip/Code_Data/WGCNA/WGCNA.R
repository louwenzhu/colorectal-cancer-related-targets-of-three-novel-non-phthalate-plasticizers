# ============================================================
# WGCNA完整分析流程：数据准备 + 批次校正 + 网络构建 + 模块筛选
# ============================================================
# 工作目录：C:/Users/ASUS/Desktop/7月重头再来/3 WGCNA
# 输入：GSE21510_expr.csv, GSE9348_expr.csv 及对应的metadata文件
# 输出：批次校正后的表达矩阵、WGCNA结果图片（6张图，三种格式）
# ============================================================

# ---- 0. 设置工作目录 ----
setwd("C:/Users/ASUS/Desktop/7月重头再来/3 WGCNA")

# ---- 1. 加载所需包 ----
library(limma)
library(sva)            # ComBat
library(WGCNA)
library(ggplot2)
library(reshape2)
library(dplyr)
library(pheatmap)
library(preprocessCore) # 归一化（如果需要）

options(stringsAsFactors = FALSE)
enableWGCNAThreads(nThreads = 4)

# ============================================================
# 第一部分：数据准备与批次校正
# ============================================================

cat("\n===== 第一部分：数据加载与批次校正 =====\n")

# ---- 读取表达矩阵 ----
expr_GSE21510 <- read.csv("GSE21510_expr.csv", row.names = 1, check.names = FALSE)
expr_GSE9348  <- read.csv("GSE9348_expr.csv",  row.names = 1, check.names = FALSE)
cat("GSE21510维度:", dim(expr_GSE21510), "\n")
cat("GSE9348维度:", dim(expr_GSE9348), "\n")

# ---- 读取分组信息 ----
meta_GSE21510 <- read.csv("GSE21510_metadata.csv", stringsAsFactors = FALSE)
meta_GSE9348  <- read.csv("GSE9348_metadata.csv",  stringsAsFactors = FALSE)

# ---- 取交集基因 ----
common_genes <- intersect(rownames(expr_GSE21510), rownames(expr_GSE9348))
cat("共同基因数:", length(common_genes), "\n")
expr_GSE21510 <- expr_GSE21510[common_genes, ]
expr_GSE9348  <- expr_GSE9348[common_genes, ]

# ---- 合并表达矩阵 ----
expr_all <- cbind(expr_GSE21510, expr_GSE9348)

# ---- 合并分组信息 ----
meta_all <- rbind(meta_GSE21510, meta_GSE9348)
meta_all <- meta_all[match(colnames(expr_all), meta_all$SampleID), ]
meta_all$Group <- factor(meta_all$Group, levels = c("Control", "CRC"))

# ---- 批次信息 ----
batch <- factor(c(rep("GSE21510", ncol(expr_GSE21510)), 
                  rep("GSE9348", ncol(expr_GSE9348))))

# ---- ComBat批次校正 ----
cat("执行ComBat批次校正...\n")
expr_matrix <- as.matrix(expr_all)
mod <- model.matrix(~ Group, data = meta_all)
expr_corrected <- ComBat(dat = expr_matrix, batch = batch, mod = mod, par.prior = TRUE)

# ---- 保存校正后的表达矩阵（用于WGCNA） ----
write.csv(expr_corrected, "expr_corrected_WGCNA.csv")
write.csv(meta_all, "sample_metadata.csv", row.names = FALSE)
cat("批次校正完成，已保存 expr_corrected_WGCNA.csv 和 sample_metadata.csv\n")

# ============================================================
# 第二部分：WGCNA分析（优化模块划分）
# ============================================================

cat("\n===== 第二部分：WGCNA分析 =====\n")

# ---- 重置并生成 datExpr ----
setwd("C:/Users/ASUS/Desktop/7月重头再来/3 WGCNA")

library(limma)
library(sva)
library(WGCNA)

# 读取批次校正后的表达矩阵（如果您已经存在）
expr_data <- read.csv("expr_corrected_WGCNA.csv", row.names = 1, check.names = FALSE)
metadata <- read.csv("sample_metadata.csv", stringsAsFactors = FALSE)
rownames(metadata) <- metadata$SampleID
metadata <- metadata[colnames(expr_data), ]
metadata$Group <- factor(metadata$Group, levels = c("Control", "CRC"))

# ---- 优化过滤策略：降低方差阈值以保留更多基因 ----
gene_vars <- apply(expr_data, 1, var, na.rm = TRUE)
# 原阈值0.5可能过高，改用0.1或使用mad筛选
gene_vars <- apply(expr_data, 1, mad)  # 使用中位数绝对偏差（更稳健）
expr_data_filtered <- expr_data[gene_vars > 0.1, ]  # 降低阈值
# 或者直接使用全部基因（不过滤），如果基因数不太多的话
# expr_data_filtered <- expr_data

if (any(is.na(expr_data_filtered))) {
  expr_data_filtered <- as.data.frame(t(apply(expr_data_filtered, 1, function(x) {
    x[is.na(x)] <- mean(x, na.rm = TRUE)
    return(x)
  })))
}
datExpr <- as.data.frame(t(expr_data_filtered))
cat("过滤后基因数:", ncol(datExpr), "\n")

# ---- 质量检查 ----
gsg <- goodSamplesGenes(datExpr, verbose = 3)
if (!gsg$allOK) {
  datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes]
}

# ---- 样本聚类（仅可视化，不剔除） ----
sample_dist <- dist(datExpr, method = "euclidean")
sample_tree <- hclust(sample_dist, method = "average")
pdf("01_Sample_Clustering_final.pdf", width = 12, height = 8)
par(cex = 0.6, mar = c(8, 4, 4, 2))
plot(sample_tree, main = "Sample Clustering (No Outlier Removal)", xlab = "", sub = "", cex = 0.6)
dev.off()
# 不剔除离群样本，保留所有样本
cat("保留所有样本，样本数:", nrow(datExpr), "\n")


# 最终样本聚类图
sample_dist_final <- dist(datExpr, method = "euclidean")
sample_tree_final <- hclust(sample_dist_final, method = "average")
pdf("01_Sample_Clustering_final.pdf", width = 12, height = 8)
par(cex = 0.6, mar = c(8, 4, 4, 2))
plot(sample_tree_final, main = "Sample Clustering (After Outlier Removal)", xlab = "", sub = "", cex = 0.6)
dev.off()

# ---- 软阈值筛选 ----
powers <- c(seq(1, 20, by = 1), seq(22, 30, by = 2))
sft <- pickSoftThreshold(datExpr, powerVector = powers, verbose = 5)

optimal_power <- sft$powerEstimate
if (is.na(optimal_power) || optimal_power < 1) {
  optimal_power <- 6
  cat("未检测到最优软阈值，使用默认值:", optimal_power, "\n")
} else {
  cat("最优软阈值:", optimal_power, "\n")
}

# 保存软阈值筛选图
pdf("02_Soft_Threshold_Selection.pdf", width = 12, height = 6)
par(mfrow = c(1, 2), mar = c(5, 5, 4, 2))
plot(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     xlab = "Soft Threshold (power)", ylab = "Scale Free Topology Model Fit (R²)",
     main = "Scale Independence", type = "n")
text(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     labels = powers, cex = 0.9, col = "red")
abline(h = 0.8, col = "blue", lty = 2, lwd = 2)
text(x = max(powers) * 0.8, y = 0.85, labels = "R² = 0.8", col = "blue", cex = 0.8)
points(optimal_power, -sign(sft$fitIndices[sft$fitIndices[,1] == optimal_power, 3]) * 
         sft$fitIndices[sft$fitIndices[,1] == optimal_power, 2], col = "blue", pch = 19, cex = 2)
text(optimal_power, -sign(sft$fitIndices[sft$fitIndices[,1] == optimal_power, 3]) * 
       sft$fitIndices[sft$fitIndices[,1] == optimal_power, 2] + 0.05,
     labels = paste0("β=", optimal_power), col = "blue", cex = 1)

plot(sft$fitIndices[, 1], sft$fitIndices[, 5],
     xlab = "Soft Threshold (power)", ylab = "Mean Connectivity",
     main = "Mean Connectivity", type = "n")
text(sft$fitIndices[, 1], sft$fitIndices[, 5],
     labels = powers, cex = 0.9, col = "red")
points(optimal_power, sft$fitIndices[sft$fitIndices[,1] == optimal_power, 5],
       col = "blue", pch = 19, cex = 2)
text(optimal_power, sft$fitIndices[sft$fitIndices[,1] == optimal_power, 5] + 50,
     labels = paste0("β=", optimal_power), col = "blue", cex = 1)
dev.off()

# ---- 网络构建与模块识别（优化参数） ----
# 用户可选择以下三种方案之一，通过修改下面的变量
# 方案选择：1=温和优化，2=精细优化，3=最精细
plan <- 1  # 默认使用精细优化

if (plan == 1) {
  # 方案A：温和优化
  minModuleSize <- 50
  mergeCutHeight <- 0.10
  deepSplit <- 2
  cat("使用方案A（温和优化）：minModuleSize=50, mergeCutHeight=0.10, deepSplit=2\n")
} else if (plan == 2) {
  # 方案B：精细优化
  minModuleSize <- 40
  mergeCutHeight <- 0.06
  deepSplit <- 3
  cat("使用方案B（精细优化）：minModuleSize=40, mergeCutHeight=0.06, deepSplit=3\n")
} else {
  # 方案C：最精细
  minModuleSize <- 30
  mergeCutHeight <- 0.03
  deepSplit <- 4
  cat("使用方案C（最精细）：minModuleSize=30, mergeCutHeight=0.03, deepSplit=4\n")
}

adjacency <- adjacency(datExpr, power = optimal_power, type = "signed")
TOM <- TOMsimilarity(adjacency, TOMType = "signed")
dissTOM <- 1 - TOM
gene_tree <- hclust(as.dist(dissTOM), method = "average")

# 动态树切割
dynamicMods <- cutreeDynamic(dendro = gene_tree, distM = dissTOM,
                             deepSplit = deepSplit, pamRespectsDendro = FALSE,
                             minClusterSize = minModuleSize)
dynamicColors <- labels2colors(dynamicMods)
cat("初始模块数:", length(unique(dynamicColors)), "\n")

# 合并相似模块
MEList <- moduleEigengenes(datExpr, colors = dynamicColors, softPower = optimal_power)
MEs <- MEList$eigengenes
MEDiss <- 1 - cor(MEs)
METree <- hclust(as.dist(MEDiss), method = "average")
merge <- mergeCloseModules(datExpr, dynamicColors, cutHeight = mergeCutHeight, verbose = 3)
mergedColors <- merge$colors
mergedMEs <- merge$newMEs
cat("合并后模块数:", length(unique(mergedColors)), "\n")

# 保存基因聚类树与模块颜色图
pdf("03_Gene_Clustering_with_Modules.pdf", width = 16, height = 10)
plotDendroAndColors(gene_tree, mergedColors,
                    "Merged Modules",
                    dendroLabels = FALSE, hang = 0.03,
                    addGuide = TRUE, guideHang = 0.05)
title(main = "Gene Clustering and Module Identification")
dev.off()

# 模块特征基因聚类图（使用pheatmap替代原plot，更稳定）
library(pheatmap)
ME_cor <- cor(mergedMEs, use = "p")
module_colors_ME <- gsub("ME", "", colnames(mergedMEs))
annotation_df <- data.frame(Module = module_colors_ME)
rownames(annotation_df) <- colnames(mergedMEs)
ann_colors <- list(Module = setNames(module_colors_ME, module_colors_ME))
ME_dist <- as.dist(1 - ME_cor)
ME_hclust <- hclust(ME_dist, method = "average")
pheatmap(ME_cor, cluster_rows = ME_hclust, cluster_cols = ME_hclust,
         color = colorRampPalette(c("blue", "white", "red"))(50),
         main = "Module Eigengene Clustering",
         display_numbers = TRUE, number_format = "%.2f", fontsize_number = 8,
         annotation_col = annotation_df, annotation_row = annotation_df,
         annotation_colors = ann_colors,
         filename = "04_Module_Eigengene_Clustering.pdf",
         width = 10, height = 10, fontsize = 10)



# ============================================================
# 模块-性状关联热图【彻底修复长度报错+缩小色块间隙+格子显示r(P)】
# ============================================================
# ---- 准备性状数据（双列：Control 和 CRC） ----
trait_control <- as.data.frame(ifelse(metadata$Group == "Control", 1, 0))
colnames(trait_control) <- "Control"
rownames(trait_control) <- rownames(metadata)

trait_crc <- as.data.frame(ifelse(metadata$Group == "CRC", 1, 0))
colnames(trait_crc) <- "CRC"
rownames(trait_crc) <- rownames(metadata)

trait <- cbind(trait_control, trait_crc)
colnames(trait) <- c("Control", "CRC")
rownames(trait) <- rownames(metadata)

# ---- 计算相关性与P值 ----
moduleTraitCor <- cor(mergedMEs, trait, use = "p")
moduleTraitPvalue <- corPvalueStudent(moduleTraitCor, nSamples = nrow(datExpr))

# ---- 按与CRC的相关性排序（降序） ----
crc_cor <- moduleTraitCor[, "CRC"]
order_idx <- order(crc_cor, decreasing = TRUE)
moduleTraitCor <- moduleTraitCor[order_idx, ]
moduleTraitPvalue <- moduleTraitPvalue[order_idx, ]

# -------------------------- 绘图代码 --------------------------
library(ggplot2)
library(tidyr)
library(ggnewscale)

# 1. 构建相关性宽表 + 模块颜色（修复长度不匹配bug）
cor_df <- as.data.frame(moduleTraitCor)
cor_df$Module <- rownames(cor_df)
# 关键修正：只对Module列去除ME前缀，不是整个cor_df
cor_df$ModColor <- gsub("ME", "", cor_df$Module)

# 2. 构建P值宽表
p_df <- as.data.frame(moduleTraitPvalue)
p_df$Module <- rownames(p_df)

# 3. 长宽转换
cor_long <- pivot_longer(cor_df, cols = c(-Module, -ModColor), names_to = "Trait", values_to = "Correlation")
p_long <- pivot_longer(p_df, cols = -Module, names_to = "Trait", values_to = "Pval")

# 4. 合并相关性+P值
plot_data <- merge(cor_long, p_long, by = c("Module", "Trait"))

# 拼接文字：相关系数换行P值
plot_data$label_text <- paste0(
  sprintf("%.2f", plot_data$Correlation),
  "\n(", sprintf("%.2e", plot_data$Pval), ")"
)

# 固定因子顺序
module_order <- rownames(moduleTraitCor)
plot_data$Module <- factor(plot_data$Module, levels = module_order)
plot_data$Trait <- factor(plot_data$Trait, levels = c("Control", "CRC"))
n_modules <- length(module_order)
color_map <- setNames(unique(plot_data$ModColor), unique(plot_data$ModColor))

# 绘图主体
p_mod_trait <- ggplot(plot_data, aes(x = Trait, y = Module)) +
  # 色块右移，缩小与热图空隙
  geom_tile(aes(x = 0.45, fill = ModColor), width = 0.12, height = 1) +
  scale_fill_manual(values = color_map, guide = "none") +
  new_scale_fill() +
  
  # 热图单元格
  geom_tile(aes(fill = Correlation), width = 1, height = 1) +
  # 两行文字，字号适配格子
  geom_text(aes(label = label_text), size = 2.9, color = "black") +
  
  # 相关性渐变色条（无标题、刻度完整不溢出）
  scale_fill_gradient2(
    low = "#4444ff", mid = "white", high = "#ee2222",
    midpoint = 0, limits = c(-1, 1),
    name = "",
    breaks = c(-1, -0.5, 0, 0.5, 1),
    guide = guide_colourbar(
      barwidth = unit(0.32, "cm"),
      barheight = unit(n_modules * 0.42, "cm"),
      title = NULL,
      label.position = "right",
      label.hjust = 0,
      frame.colour = "black",
      frame.linewidth = 0.3
    )
  ) +
  
  labs(title = "Module–trait relationships", x = "", y = "") +
  coord_fixed(ratio = 0.35) +
  # 缩小X左侧拓展空白，压缩色块与热图间距
  scale_x_discrete(expand = c(0.18, 0.05)) +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    panel.border = element_blank(),
    plot.background = element_rect(fill = "white"),
    
    axis.text.x = element_text(size = 13, face = "bold"),
    axis.ticks.x = element_blank(),
    axis.text.y = element_text(size = 10, hjust = 1),
    axis.ticks.y = element_blank(),
    
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold", margin = margin(b=12)),
    
    legend.position = "right",
    legend.margin = margin(t = 15, b = 15, l = 5, r = 2),
    legend.title = element_blank(),
    legend.text = element_text(size = 9),
    
    # 收窄画布左侧总留白
    plot.margin = margin(t = 8, r = 3, b = 8, l = 26)
  )

# 保存图片
plot_w <- 6.0
plot_h <- max(7.8, n_modules * 0.52)

ggsave("05_Module_Trait_Heatmap.pdf", p_mod_trait, width = plot_w, height = plot_h, dpi = 600)
ggsave("05_Module_Trait_Heatmap.png", p_mod_trait, width = plot_w, height = plot_h, dpi = 600)
ggsave("05_Module_Trait_Heatmap.jpg", p_mod_trait, width = plot_w, height = plot_h, dpi = 600)

cat("热图导出完成：左侧色块间隙缩小，单元格显示r+P值，无长度报错\n")
# -------------------------- 绘图代码结束 --------------------------

# ============================================================
# 核心模块MM-GS散点图（修正版）
# ============================================================

# ---- 找出与CRC最相关的模块 ----
crc_cor <- moduleTraitCor[, "CRC"]
most_cor_idx <- which.max(abs(crc_cor))
most_cor_module <- rownames(moduleTraitCor)[most_cor_idx]
most_cor_color <- gsub("ME", "", most_cor_module)
cat("\n与CRC最相关的模块:", most_cor_color, "\n")
cat("相关性:", crc_cor[most_cor_idx], "\n")

# ---- 计算MM和GS ----
geneModuleMembership <- cor(datExpr, mergedMEs, use = "p")
geneSignificance <- cor(datExpr, trait$CRC, use = "p")

# 获取核心模块基因
module_genes <- names(mergedColors[mergedColors == most_cor_color])
if (length(module_genes) == 0) {
  stop(paste("模块", most_cor_color, "没有基因，请检查合并后的模块颜色。"))
}
cat("核心模块基因数:", length(module_genes), "\n")

# 提取MM和GS（取绝对值）
mm <- abs(geneModuleMembership[module_genes, most_cor_module])
gs <- abs(geneSignificance[module_genes, 1])

# ---- 计算相关系数和P值 ----
cor_mm_gs <- cor(mm, gs, use = "p")
cor_pval <- corPvalueStudent(cor_mm_gs, length(mm))
cat(sprintf("MM-GS相关性: r = %.3f, P = %.2e\n", cor_mm_gs, cor_pval))

# ---- 绘制散点图（ggplot2，坐标轴从0开始） ----
library(ggplot2)
plot_df <- data.frame(MM = mm, GS = gs)

p_mm_gs <- ggplot(plot_df, aes(x = MM, y = GS)) +
  geom_point(alpha = 0.6, size = 1.5, color = most_cor_color) +
  geom_smooth(method = "lm", se = TRUE, color = "red", alpha = 0.2) +
  # 添加相关系数和P值标注（放在左上角）
  annotate("text", 
           x = 0.05, y = 0.95,
           label = paste0("cor = ", sprintf("%.3f", cor_mm_gs), 
                          "\nP = ", sprintf("%.2e", cor_pval)),
           size = 5, hjust = 0, vjust = 1, fontface = "bold") +
  # 设置坐标轴范围从0开始
  scale_x_continuous(limits = c(0, 1), expand = c(0.01, 0)) +
  scale_y_continuous(limits = c(0, 1), expand = c(0.01, 0)) +
  labs(
    title = paste("Module Membership vs. Gene Significance (", most_cor_color, " module)", sep = ""),
    x = paste("Module Membership in", most_cor_color, "module"),
    y = "Gene Significance for CRC"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
    axis.title = element_text(face = "bold", size = 14),
    axis.text = element_text(size = 12),
    panel.grid.minor = element_blank()
  )

print(p_mm_gs)

# ---- 保存 ----
ggsave("06_MM_GS_Correlation.pdf", p_mm_gs, width = 8, height = 6)
ggsave("06_MM_GS_Correlation.png", p_mm_gs, width = 8, height = 6, dpi = 600)
ggsave("06_MM_GS_Correlation.jpg", p_mm_gs, width = 8, height = 6, dpi = 600, device = "jpeg")

cat("MM-GS散点图已保存（PDF/PNG/JPG）\n")

# ---- 输出枢纽基因（MM>0.7 且 GS>0.15） ----
hub_genes <- data.frame(
  Gene = module_genes,
  MM = mm,
  GS = gs,
  stringsAsFactors = FALSE
)
hub_genes <- hub_genes[hub_genes$MM > 0.7 & hub_genes$GS > 0.15, ]
cat("枢纽基因数（MM > 0.7, GS > 0.15）:", nrow(hub_genes), "\n")
if (nrow(hub_genes) > 0) {
  write.csv(hub_genes, paste0("Hub_Genes_", most_cor_color, ".csv"), row.names = FALSE)
  cat("枢纽基因已保存至: Hub_Genes_", most_cor_color, ".csv\n")
  print(head(hub_genes, 10))
}


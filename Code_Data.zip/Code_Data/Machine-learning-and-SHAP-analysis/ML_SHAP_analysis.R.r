# =============================================================================
#  Machine-learning and SHAP analysis
#  Core-target prioritisation for three alternative non-phthalate plasticizers
#  (DOTP, DINCH, TMCH) in colorectal cancer
#
#  Final version accompanying the manuscript.
#
#  Cohorts (six in total)
#    training        GSE21510 + GSE9348, merged and ComBat batch-corrected
#                    230 samples (37 normal / 193 CRC)
#    GSE24514         49 samples (15 / 34)
#    GSE32323         34 samples (17 / 17)
#    TCGA-CRC        431 samples (51 / 380)  = TCGA-COAD + TCGA-READ (COADREAD)
#    GSE44076        148 samples (50 / 98)
#    GSE113513        28 samples (14 / 14, paired tumour / adjacent normal)
#
#  Model grid
#    22 single-algorithm models
#  + 96 two-stage pipelines (8 feature-selection strategies x 12 classifiers)
#  = 118 pipelines, each evaluated in all six cohorts (708 metric rows)
#
#  Outputs
#    results/data/     cohort summary, per-fold CV metrics, external-validation
#                      metrics, model ranking, null analyses, SHAP values
#    results/figures/  AUC heatmaps, ROC curves, SHAP plots
# =============================================================================

# =============================================================================
# 0.  Data sources
# =============================================================================
# GEO series matrices (GEOquery or manual download from
# https://www.ncbi.nlm.nih.gov/geo/):
#   GSE21510, GSE9348    training cohort
#   GSE24514, GSE32323   external validation
#   GSE44076             external validation
#   GSE113513            external validation (paired design)
#
# TCGA colorectal cohort -- UCSC Xena hub, HiSeqV2 (log2(norm_count+1)):
#   https://tcga-xena-hub.s3.us-east-1.amazonaws.com/download/TCGA.COADREAD.sampleMap%2FHiSeqV2.gz
#   Sample type is read from the TCGA barcode (characters 14-15):
#     01 = primary solid tumour, 11 = solid tissue normal.
#   Recurrent (02) and metastatic (06) samples are excluded so that the
#   contrast matches the other cohorts (primary tumour vs normal mucosa).
#   Using the combined COADREAD matrix yields the true colorectal cohort
#   (colon adenocarcinoma + rectum adenocarcinoma).
#
# All cohorts are restricted to the same 79-gene panel shared between the
# plasticizer-associated and CRC-associated gene sets.

# =============================================================================
# 1.  Setup
# =============================================================================
rm(list = ls()); gc()

required_packages <- c(
  "glmnet", "e1071", "randomForestSRC", "gbm", "MASS", "xgboost", "klaR",
  "plsRglm", "mboost", "caret", "pROC", "PRROC", "kernelshap", "shapviz",
  "ComplexHeatmap", "circlize", "grid", "ggplot2", "cowplot", "tidyr",
  "readxl", "foreach", "doParallel"
)
for (pkg in required_packages) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

# ---- paths: adjust DATA_DIR to the folder holding the processed matrices ----
DATA_DIR <- "Processed_Data"
OUT      <- "results"
for (d in c("data", "figures", "params", "logs")) {
  dir.create(file.path(OUT, d), showWarnings = FALSE, recursive = TRUE)
}

SEED      <- 123        # every random step is seeded
N_WORKERS <- 12         # parallel workers
DPI       <- 600        # figure resolution

say <- function(...) {
  msg <- paste0(sprintf("[%s] ", format(Sys.time(), "%H:%M:%S")), paste0(..., collapse = ""))
  cat(msg, "\n")
  cat(msg, "\n", file = file.path(OUT, "logs", "run_log.txt"), append = TRUE)
}

set.seed(SEED)

# =============================================================================
# 2.  Cohort definition
# =============================================================================
# Each cohort file is a genes x samples matrix (log-scale expression) plus a
# sample table with columns `sample_id` and `group` (control / crc).

normalise_group <- function(g) {
  g <- tolower(g)
  g[grep("control|normal|healthy|adjacent", g)] <- "control"
  g[grep("crc|cancer|tumor|tumour|carcinoma|colorectal|adenocarcinoma", g)] <- "crc"
  factor(g, levels = c("control", "crc"))
}

load_cohort <- function(expr_file, meta_file) {
  ex <- read.csv(expr_file, row.names = 1, check.names = FALSE)
  if (grepl("\\.xlsx$", meta_file, ignore.case = TRUE)) {
    md <- as.data.frame(readxl::read_excel(meta_file))
    colnames(md) <- tolower(colnames(md))
    sc  <- grep("sample|gsm|^id", colnames(md), value = TRUE)[1]
    gc_ <- grep("group|status|type|class|disease|tissue", colnames(md), value = TRUE)[1]
    md  <- data.frame(sample_id = as.character(md[[sc]]),
                      group = normalise_group(md[[gc_]]))
  } else {
    md <- read.csv(meta_file, check.names = FALSE, stringsAsFactors = FALSE)
    gc_ <- grep("group|status|type|class", colnames(md), value = TRUE)[1]
    md  <- data.frame(sample_id = as.character(md[[1]]),
                      group = normalise_group(md[[gc_]]))
  }
  e2 <- as.data.frame(t(ex)); e2$sample_id <- rownames(e2)
  d  <- merge(md, e2, by = "sample_id")
  rownames(d) <- d$sample_id; d$sample_id <- NULL
  d
}

say("STEP 1  loading cohorts")
train_data <- load_cohort(file.path(DATA_DIR, "expr_79genes_extracted.csv"),
                          file.path(DATA_DIR, "sample_metadata.csv"))
gene_cols  <- setdiff(colnames(train_data), "group")

COHORTS <- list(
  GSE24514  = load_cohort(file.path(DATA_DIR, "expr_79genes_GSE24514.csv"),
                          file.path(DATA_DIR, "GSE24514 Sample metadata.xlsx")),
  GSE32323  = load_cohort(file.path(DATA_DIR, "expr_79genes_GSE32323.csv"),
                          file.path(DATA_DIR, "GSE32323 Sample metadata.xlsx")),
  TCGA_CRC  = load_cohort(file.path(DATA_DIR, "expr_79genes_TCGA_CRC.csv"),
                          file.path(DATA_DIR, "TCGA_CRC_sample_info.csv")),
  GSE44076  = load_cohort(file.path(DATA_DIR, "expr_79genes_GSE44076.csv"),
                          file.path(DATA_DIR, "GSE44076_sample_info.xlsx")),
  GSE113513 = load_cohort(file.path(DATA_DIR, "expr_79genes_GSE113513.csv"),
                          file.path(DATA_DIR, "GSE113513_sample_info.csv"))
)

# ---- normalisation -----------------------------------------------------------
# Training set: Z-score against its own mean/SD, then Gaussian noise (SD 0.01)
# as a mild regulariser (seeded, so reproducible).
# External cohorts: Z-score within cohort, because only the relative ordering of
# samples matters for the rank-based metrics used here.
tm  <- apply(train_data[, gene_cols], 2, mean)
tsd <- apply(train_data[, gene_cols], 2, sd)
train_data[, gene_cols] <- scale(train_data[, gene_cols], center = tm, scale = tsd)
set.seed(SEED)
for (g in gene_cols) {
  train_data[, g] <- train_data[, g] + rnorm(nrow(train_data), 0, 0.01)
}
for (nm in names(COHORTS)) {
  miss <- setdiff(gene_cols, colnames(COHORTS[[nm]]))
  if (length(miss)) say("  WARNING ", nm, " missing ", length(miss), " genes")
  COHORTS[[nm]][, gene_cols] <- scale(COHORTS[[nm]][, gene_cols])
}

say("  training : ", nrow(train_data), " (",
    paste(table(train_data$group), collapse = "/"), ")")
for (nm in names(COHORTS)) {
  say("  ", nm, ": ", nrow(COHORTS[[nm]]), " (",
      paste(table(COHORTS[[nm]]$group), collapse = "/"), ")")
}
write.csv(data.frame(
  cohort    = c("training", names(COHORTS)),
  n_samples = c(nrow(train_data), sapply(COHORTS, nrow)),
  n_control = c(sum(train_data$group == "control"),
                sapply(COHORTS, function(d) sum(d$group == "control"))),
  n_crc     = c(sum(train_data$group == "crc"),
                sapply(COHORTS, function(d) sum(d$group == "crc")))),
  file.path(OUT, "data", "00_cohort_summary.csv"), row.names = FALSE)

# =============================================================================
# 3.  Model grid -- 118 pipelines
# =============================================================================
SINGLE_ALGORITHMS <- list(
  list(name = "Lasso",            method = "lasso"),
  list(name = "Ridge",            method = "ridge"),
  list(name = "Enet_alpha0.1",    method = "enet", alpha = 0.1),
  list(name = "Enet_alpha0.2",    method = "enet", alpha = 0.2),
  list(name = "Enet_alpha0.3",    method = "enet", alpha = 0.3),
  list(name = "Enet_alpha0.4",    method = "enet", alpha = 0.4),
  list(name = "Enet_alpha0.5",    method = "enet", alpha = 0.5),
  list(name = "Enet_alpha0.6",    method = "enet", alpha = 0.6),
  list(name = "Enet_alpha0.7",    method = "enet", alpha = 0.7),
  list(name = "Enet_alpha0.8",    method = "enet", alpha = 0.8),
  list(name = "Enet_alpha0.9",    method = "enet", alpha = 0.9),
  list(name = "SVM",              method = "svm"),
  list(name = "RF",               method = "rf"),
  list(name = "glmBoost",         method = "glmboost"),
  list(name = "Stepglm_forward",  method = "stepglm", direction = "forward"),
  list(name = "Stepglm_backward", method = "stepglm", direction = "backward"),
  list(name = "Stepglm_both",     method = "stepglm", direction = "both"),
  list(name = "GBM",              method = "gbm"),
  list(name = "LDA",              method = "lda"),
  list(name = "XGBoost",          method = "xgboost"),
  list(name = "NaiveBayes",       method = "naivebayes"),
  list(name = "plsRglm",          method = "plsrglm")
)

FS_METHODS <- list(
  list(name = "Lasso",     method = "lasso"),
  list(name = "Ridge",     method = "ridge"),
  list(name = "Enet",      method = "enet", alpha = 0.5),
  list(name = "RF",        method = "rf"),
  list(name = "glmBoost",  method = "glmboost"),
  list(name = "Stepglm",   method = "stepglm", direction = "both"),
  list(name = "Enet_a0.1", method = "enet", alpha = 0.1),
  list(name = "Enet_a0.9", method = "enet", alpha = 0.9)
)

CLASSIFIERS <- list(
  list(name = "Lasso",      method = "lasso"),
  list(name = "Ridge",      method = "ridge"),
  list(name = "Enet",       method = "enet", alpha = 0.5),
  list(name = "SVM",        method = "svm"),
  list(name = "RF",         method = "rf"),
  list(name = "glmBoost",   method = "glmboost"),
  list(name = "Stepglm",    method = "stepglm", direction = "both"),
  list(name = "GBM",        method = "gbm"),
  list(name = "LDA",        method = "lda"),
  list(name = "XGBoost",    method = "xgboost"),
  list(name = "NaiveBayes", method = "naivebayes"),
  list(name = "plsRglm",    method = "plsrglm")
)

all_models <- c(
  lapply(SINGLE_ALGORITHMS, function(z) c(z, list(type = "single"))),
  unlist(lapply(FS_METHODS, function(fs) {
    lapply(CLASSIFIERS, function(cl) {
      list(name = paste0(fs$name, "+", cl$name), type = "two-stage",
           fs_method = fs$method,
           fs_params = fs[setdiff(names(fs), c("name", "method"))],
           clf_method = cl$method,
           clf_params = cl[setdiff(names(cl), c("name", "method"))])
    })
  }), recursive = FALSE)
)
say("STEP 2  model grid: ", length(all_models), " pipelines (",
    length(SINGLE_ALGORITHMS), " single + ",
    length(all_models) - length(SINGLE_ALGORITHMS), " two-stage)")

# =============================================================================
# 4.  Model hyperparameters
# =============================================================================
# Hyperparameters are PRE-SPECIFIED, not optimised by grid search, so that no
# information from the held-out cohorts can influence model construction.
# Where a package offers an internal cross-validation (regularised regression
# lambda, GBM and XGBoost iteration counts, plsRglm components) that internal CV
# is run inside the training partition only.

train_classifier <- function(x, y, method, params = list()) {
  y <- factor(y, levels = c("control", "crc"))
  df <- data.frame(y = y, x, check.names = FALSE)

  if (method %in% c("lasso", "ridge", "enet")) {
    alpha <- if (method == "lasso") 1 else if (method == "ridge") 0 else
      (if (is.null(params$alpha)) 0.5 else params$alpha)
    set.seed(SEED)
    f <- glmnet::cv.glmnet(as.matrix(x), y, family = "binomial", alpha = alpha,
                           nfolds = 10)
    return(list(fit = f, method = method, alpha = alpha, lambda = f$lambda.min))
  }
  if (method == "svm") {
    # radial kernel, cost = 1, gamma = 1/p
    f <- e1071::svm(y ~ ., data = df, kernel = "radial", cost = 1,
                    gamma = 1 / ncol(x), scale = FALSE, probability = TRUE)
    return(list(fit = f, method = method))
  }
  if (method == "rf") {
    # 1,000 trees (package default), minimum terminal node size 5
    f <- randomForestSRC::rfsrc(y ~ ., data = df, ntree = 1000, nodesize = 5,
                                importance = TRUE)
    return(list(fit = f, method = method))
  }
  if (method == "glmboost") {
    # 100 boosting iterations, nu = 0.1
    f <- mboost::glmboost(y ~ ., data = df,
                          control = mboost::boost_control(mstop = 100, nu = 0.1))
    return(list(fit = f, method = method))
  }
  if (method == "stepglm") {
    d <- if (is.null(params$direction)) "both" else params$direction
    f <- stats::glm(y ~ ., data = df, family = "binomial")
    f <- stats::step(f, direction = d, trace = 0)
    return(list(fit = f, method = method))
  }
  if (method == "gbm") {
    # 5,000 trees, interaction depth 3, shrinkage 0.001; the number of trees is
    # fixed by 5-fold internal cross-validation
    f  <- gbm::gbm(y ~ ., data = df, distribution = "bernoulli", n.trees = 5000,
                   interaction.depth = 3, shrinkage = 0.001, cv.folds = 5,
                   verbose = FALSE)
    bi <- tryCatch(gbm::gbm.perf(f, method = "cv", plot.it = FALSE),
                   error = function(e) 5000)
    return(list(fit = f, method = method, n.trees = as.integer(bi)))
  }
  if (method == "lda") {
    f <- MASS::lda(y ~ ., data = df)
    return(list(fit = f, method = method))
  }
  if (method == "xgboost") {
    # max_depth 3, eta 0.01; the number of rounds is fixed by 5-fold internal CV
    dt <- xgboost::xgb.DMatrix(as.matrix(x), label = as.integer(y) - 1)
    p  <- list(objective = "binary:logistic", eval_metric = "auc",
               max_depth = 3, eta = 0.01, nthread = 1)
    set.seed(SEED)
    cvf <- xgboost::xgb.cv(params = p, data = dt, nrounds = 500, nfold = 5,
                           verbose = 0, prediction = FALSE)
    nr  <- if (!is.null(cvf$best_iteration)) cvf$best_iteration else
      nrow(cvf$evaluation_log)
    nr  <- max(1L, as.integer(nr))
    return(list(fit = xgboost::xgb.train(params = p, data = dt, nrounds = nr,
                                         verbose = 0),
                method = method, nrounds = nr))
  }
  if (method == "naivebayes") {
    f <- klaR::NaiveBayes(y ~ ., data = df)
    return(list(fit = f, method = method))
  }
  if (method == "plsrglm") {
    # number of components chosen by the package's internal cross-validation
    f <- plsRglm::plsRglm(y ~ ., data = df, modele = "pls-glm-family",
                          family = "binomial", verbose = FALSE)
    return(list(fit = f, method = method, nt = f$nt))
  }
  stop("unknown method: ", method)
}

predict_model <- function(m, newx) {
  if (m$method %in% c("lasso", "ridge", "enet")) {
    return(as.numeric(predict(m$fit, newx = as.matrix(newx), type = "response",
                              s = m$lambda)))
  }
  if (m$method == "svm") {
    return(attr(predict(m$fit, newdata = as.data.frame(newx), probability = TRUE),
                "probabilities")[, "crc"])
  }
  if (m$method == "rf") {
    return(as.numeric(predict(m$fit, newdata = as.data.frame(newx))$predicted[, "crc"]))
  }
  if (m$method == "glmboost") {
    return(as.numeric(predict(m$fit, newdata = as.data.frame(newx),
                              type = "response")))
  }
  if (m$method %in% c("stepglm", "lda", "naivebayes")) {
    return(as.numeric(predict(m$fit, newdata = as.data.frame(newx),
                              type = "response")$posterior[, "crc"]))
  }
  if (m$method == "gbm") {
    return(as.numeric(predict(m$fit, newdata = as.data.frame(newx),
                              n.trees = m$n.trees, type = "response")))
  }
  if (m$method == "xgboost") {
    return(as.numeric(predict(m$fit, xgboost::xgb.DMatrix(as.matrix(newx)))))
  }
  if (m$method == "plsrglm") {
    return(as.numeric(predict(m$fit, newdata = as.data.frame(newx),
                              type = "response")))
  }
  stop("unknown method: ", m$method)
}

feature_select <- function(x, y, method, params = list()) {
  keep <- colnames(x)
  if (method %in% c("lasso", "ridge", "enet")) {
    alpha <- if (method == "lasso") 1 else if (method == "ridge") 0 else
      (if (is.null(params$alpha)) 0.5 else params$alpha)
    set.seed(SEED)
    f <- glmnet::cv.glmnet(as.matrix(x), y, family = "binomial", alpha = alpha,
                           nfolds = 10)
    cf <- as.matrix(coef(f, s = f$lambda.min))
    keep <- setdiff(rownames(cf)[which(cf[, 1] != 0)], "(Intercept)")
  } else if (method == "rf") {
    f <- randomForestSRC::rfsrc(y ~ ., data = data.frame(y = y, x),
                                ntree = 1000, importance = TRUE)
    v <- randomForestSRC::vimp(f)$importance[, 1]
    keep <- names(sort(v, decreasing = TRUE))[seq_len(min(30, length(v)))]
  } else if (method == "glmboost") {
    f <- mboost::glmboost(y ~ ., data = data.frame(y = y, x),
                          control = mboost::boost_control(mstop = 100, nu = 0.1))
    cf <- f$coef()
    keep <- unique(names(cf)[cf != 0 & names(cf) != "(Intercept)"])
  } else if (method == "stepglm") {
    d <- if (is.null(params$direction)) "both" else params$direction
    f <- stats::glm(y ~ ., data = data.frame(y = y, x), family = "binomial")
    f <- stats::step(f, direction = d, trace = 0)
    cf <- stats::coef(f)
    keep <- setdiff(names(cf)[cf != 0], "(Intercept)")
  }
  keep <- intersect(keep, colnames(x))
  if (length(keep) < 2) keep <- colnames(x)   # never return a degenerate set
  keep
}

# =============================================================================
# 5.  Metrics
# =============================================================================
calc_metrics <- function(truth, prob) {
  truth <- factor(truth, levels = c("control", "crc"))
  r  <- pROC::roc(truth, prob, quiet = TRUE)
  ci <- tryCatch(as.numeric(pROC::ci.auc(r, method = "delong")),
                 error = function(e) c(NA, NA, NA))
  # Youden-optimal threshold; all threshold-dependent metrics use it
  th <- tryCatch(as.numeric(pROC::coords(r, "best", best.method = "youden",
                                         ret = "threshold")[1]),
                 error = function(e) 0.5)
  pred <- factor(ifelse(prob >= th, "crc", "control"), levels = c("control", "crc"))
  cm <- table(truth, pred)
  tp <- cm["crc", "crc"]; tn <- cm["control", "control"]
  fp <- cm["control", "crc"]; fn <- cm["crc", "control"]
  acc  <- (tp + tn) / sum(cm)
  sens <- tp / (tp + fn); spec <- tn / (tn + fp)
  prec <- if ((tp + fp) == 0) NA else tp / (tp + fp)
  f1   <- if (is.na(prec) || (prec + sens) == 0) NA else
    2 * prec * sens / (prec + sens)
  mcc_den <- sqrt(prod(as.numeric(c(tp + fp, tp + fn, tn + fp, tn + fn))))
  mcc <- if (mcc_den == 0) NA else (tp * tn - fp * fn) / mcc_den
  # PR-AUC by trapezoidal integration
  pr <- tryCatch(as.numeric(PRROC::pr.curve(
    scores.class0 = prob[truth == "crc"],
    scores.class1 = prob[truth == "control"], curve = TRUE)$auc.integral),
    error = function(e) NA)
  list(auc = as.numeric(pROC::auc(r)), auc_lo = ci[1], auc_hi = ci[3],
       pr_auc = pr, f1 = f1, accuracy = acc, sensitivity = sens,
       specificity = spec, precision = prec, mcc = mcc,
       brier = mean((prob - (as.integer(truth) - 1))^2), threshold = th)
}

# =============================================================================
# 6.  Stratified 10-fold cross-validation (training cohort only)
# =============================================================================
# Feature selection is performed INSIDE each fold on the training partition
# only, so held-out samples never contribute to the definition of the gene
# subset.  Class frequencies are balanced with inverse-frequency weights.
say("STEP 3  stratified 10-fold cross-validation")
set.seed(SEED)
folds <- caret::createFolds(train_data$group, k = 10, list = TRUE, returnTrain = TRUE)

cv_one <- function(mc, fold_idx) {
  tr <- train_data[fold_idx, ]; te <- train_data[-fold_idx, ]
  set.seed(SEED)
  if (mc$type == "single") {
    sel <- gene_cols
    m   <- train_classifier(tr[, gene_cols], tr$group, mc$method,
                            mc[setdiff(names(mc), c("name", "type", "method"))])
  } else {
    sel <- feature_select(tr[, gene_cols], tr$group, mc$fs_method, mc$fs_params)
    m   <- train_classifier(tr[, sel, drop = FALSE], tr$group, mc$clf_method,
                            mc$clf_params)
  }
  p <- predict_model(m, te[, sel, drop = FALSE])
  c(calc_metrics(te$group, p), list(n_genes = length(sel)))
}

PKGS <- c("glmnet","e1071","randomForestSRC","gbm","MASS","xgboost","klaR",
          "plsRglm","mboost","pROC","PRROC")
use_parallel <- length(all_models) > 20 && N_WORKERS > 1
if (use_parallel) {
  cl <- parallel::makeCluster(min(N_WORKERS, max(1, parallel::detectCores() - 1)))
  doParallel::registerDoParallel(cl)
  clusterExport(cl, c("train_data","gene_cols","all_models","folds","cv_one",
                      "train_classifier","predict_model","feature_select",
                      "calc_metrics","SEED"), envir = globalenv())
  clusterEvalQ(cl, suppressPackageStartupMessages({
    library(glmnet); library(e1071); library(randomForestSRC); library(gbm)
    library(MASS); library(xgboost); library(klaR); library(plsRglm)
    library(mboost); library(pROC); library(PRROC); library(caret)
  }))
}
cv_res <- foreach::foreach(i = seq_along(all_models), .combine = rbind,
                           .packages = PKGS, .errorhandling = "pass") %do% {
  mc <- all_models[[i]]
  rows <- lapply(seq_along(folds), function(k) {
    r <- tryCatch(cv_one(mc, folds[[k]]), error = function(e) NULL)
    if (is.null(r)) return(NULL)
    data.frame(model_name = mc$name, fold = k,
               auc = r$auc, pr_auc = r$pr_auc, f1 = r$f1, accuracy = r$accuracy,
               sensitivity = r$sensitivity, specificity = r$specificity,
               precision = r$precision, mcc = r$mcc, brier = r$brier,
               n_genes = r$n_genes, stringsAsFactors = FALSE)
  })
  do.call(rbind, rows)
}
if (use_parallel) parallel::stopCluster(cl)
write.csv(cv_res, file.path(OUT, "data", "01_cv_per_fold_metrics.csv"),
          row.names = FALSE)
say("  fold rows: ", nrow(cv_res), "  models: ", length(unique(cv_res$model_name)))

# =============================================================================
# 7.  External validation in all six cohorts
# =============================================================================
say("STEP 4  external validation (six cohorts)")
safe_name <- function(x) gsub("[^A-Za-z0-9_.-]", "_", x)
CACHE <- file.path(OUT, "data", "per_model"); dir.create(CACHE, showWarnings = FALSE)
all_names <- vapply(all_models, function(z) z$name, "")
todo <- all_names[!file.exists(file.path(CACHE, paste0(safe_name(all_names), ".rds")))]

if (length(todo)) {
  cl <- parallel::makeCluster(min(N_WORKERS, length(todo)))
  doParallel::registerDoParallel(cl)
  clusterExport(cl, c("train_data","gene_cols","all_models","todo","COHORTS",
                      "train_classifier","predict_model","feature_select",
                      "calc_metrics","SEED","safe_name","CACHE"), envir = globalenv())
  clusterEvalQ(cl, suppressPackageStartupMessages({
    library(glmnet); library(e1071); library(randomForestSRC); library(gbm)
    library(MASS); library(xgboost); library(klaR); library(plsRglm)
    library(mboost); library(pROC); library(PRROC)
  }))
  foreach::foreach(j = seq_along(todo), .packages = PKGS,
                   .errorhandling = "pass") %dopar% {
    nm <- todo[j]
    mc <- all_models[[which(vapply(all_models, function(z) z$name, "") == nm)]]
    set.seed(SEED + 7 * j)
    rows <- tryCatch({
      if (mc$type == "single") {
        sel <- gene_cols
        m <- train_classifier(train_data[, gene_cols], train_data$group,
                              mc$method, mc[setdiff(names(mc), c("name","type","method"))])
      } else {
        sel <- feature_select(train_data[, gene_cols], train_data$group,
                              mc$fs_method, mc$fs_params)
        m <- train_classifier(train_data[, sel, drop = FALSE], train_data$group,
                              mc$clf_method, mc$clf_params)
      }
      mk <- function(dat, cohort) {
        if (!all(sel %in% colnames(dat))) return(NULL)
        p <- predict_model(m, dat[, sel, drop = FALSE])
        r <- calc_metrics(dat$group, p)
        data.frame(model_name = nm, model_type = mc$type, cohort = cohort,
                   n_genes = length(sel), auc = r$auc, auc_lo = r$auc_lo,
                   auc_hi = r$auc_hi, pr_auc = r$pr_auc, f1 = r$f1,
                   accuracy = r$accuracy, sensitivity = r$sensitivity,
                   specificity = r$specificity, precision = r$precision,
                   mcc = r$mcc, brier = r$brier, threshold = r$threshold,
                   features = paste(sel, collapse = ","), row.names = NULL)
      }
      rbind(mk(train_data, "training"),
            do.call(rbind, lapply(names(COHORTS), function(cn) mk(COHORTS[[cn]], cn))))
    }, error = function(e) NULL)
    if (!is.null(rows)) saveRDS(rows, file.path(CACHE, paste0(safe_name(nm), ".rds")))
    NULL
  }
  parallel::stopCluster(cl)
}
final_res <- do.call(rbind, lapply(list.files(CACHE, full.names = TRUE), readRDS))
for (cc in c("auc","auc_lo","auc_hi","pr_auc","f1","accuracy","sensitivity",
             "specificity","precision","mcc","brier","threshold")) {
  final_res[[cc]] <- round(as.numeric(final_res[[cc]]), 4)
}
write.csv(final_res, file.path(OUT, "data", "03_external_validation_metrics.csv"),
          row.names = FALSE)
say("  metric rows: ", nrow(final_res), "  models: ",
    length(unique(final_res$model_name)))

# =============================================================================
# 8.  Model selection
# =============================================================================
# Pipelines are ranked by the MEAN AUC ACROSS THE SIX COHORTS.  Because the
# near-ceiling discrimination compresses the ranking, the reported model is
# chosen from the leading group on the basis of PARSIMONY (fewest retained
# genes) and stability of the retained gene set -- not on nominal AUC.
say("STEP 5  model selection")
w <- reshape(final_res[, c("model_name","cohort","auc")], idvar = "model_name",
             timevar = "cohort", direction = "wide")
sel_tab <- data.frame(model_name = w$model_name)
for (cn in c("training", names(COHORTS))) {
  tag <- if (cn == "training") "train" else cn
  sel_tab[[paste0(tag, "_auc")]] <- w[[paste0("auc.", cn)]]
}
auc_cols <- grep("_auc$", colnames(sel_tab), value = TRUE)
sel_tab$mean_auc <- rowMeans(sel_tab[, auc_cols], na.rm = TRUE)
sel_tab <- sel_tab[!is.na(sel_tab$mean_auc), ]
sel_tab <- sel_tab[order(-sel_tab$mean_auc), ]
sel_tab[, 2:ncol(sel_tab)] <- round(sel_tab[, 2:ncol(sel_tab)], 4)
write.csv(sel_tab, file.path(OUT, "data", "04_model_selection_summary.csv"),
          row.names = FALSE)

write.csv(data.frame(
  model_name = all_names,
  features = vapply(all_names, function(nm) {
    r <- final_res$features[final_res$model_name == nm]
    if (length(r)) r[1] else ""
  }, "")),
  file.path(OUT, "data", "06b_all_selected_features.csv"), row.names = FALSE)

REPORTED <- "RF+LDA"
say("  reported model: ", REPORTED, "  rank ",
    which(sel_tab$model_name == REPORTED), " of ", nrow(sel_tab))

# =============================================================================
# 9.  SHAP analysis of the reported model
# =============================================================================
# kernelshap: predicted probability of the CRC class as the explained output,
# 100 randomly drawn training samples as the background, tolerance 0.05 and at
# most five iterations.  (The package default tolerance of 0.005 would require
# roughly 1,000 model evaluations per sample and is unnecessary here.)
say("STEP 6  SHAP")
CORE <- c("ABCG2", "CDK1", "CA7", "MET", "TDP2")

feat_row <- read.csv(file.path(OUT, "data", "06b_all_selected_features.csv"))
feats <- strsplit(feat_row$features[feat_row$model_name == REPORTED][1], ",")[[1]]
mc_rep <- all_models[[which(all_names == REPORTED)]]
set.seed(SEED)
m_rep <- train_classifier(train_data[, feats, drop = FALSE], train_data$group,
                          mc_rep$clf_method, mc_rep$clf_params)

x <- train_data[, feats, drop = FALSE]
set.seed(SEED); bg_idx <- sample(seq_len(nrow(x)), 100)
set.seed(SEED)
shp <- kernelshap::kernelshap(
  object = m_rep, X = x, bg_X = x[bg_idx, , drop = FALSE],
  pred_fun = function(object, X) predict_model(object, X),
  tol = 0.05, max_iter = 5, parallel = TRUE, parallel_args = list(spec = 8)
)
sv <- shapviz::shapviz(shp)
S  <- sv$S
write.csv(S, file.path(OUT, "data", "09_shap_values.csv"))
imp <- sort(colMeans(abs(S)), decreasing = TRUE)
write.csv(data.frame(rank = seq_along(imp), gene = names(imp),
                     mean_abs_shap = round(as.numeric(imp), 4)),
          file.path(OUT, "data", "10_shap_importance_ranking.csv"), row.names = FALSE)
saveRDS(list(sv = sv, S = S), file.path(OUT, "data", "shap_reported.rds"))
say("  SHAP top-5: ", paste(names(imp)[1:5], collapse = ", "))

# ---- representative single samples -------------------------------------------
# One CRC and one control sample whose predicted probability is closest to the
# median of its own class, so the plots show a typical rather than an extreme
# prediction.
probs <- predict_model(m_rep, x)
ci <- which(train_data$group == "crc")
crc_s <- ci[which.min(abs(probs[ci] - median(probs[ci])))]
ni <- which(train_data$group == "control")
ctl_s <- ni[which.min(abs(probs[ni] - median(probs[ni])))]

# ---- reduced shapviz object: five core genes + one pooled term ---------------
# The full model retains 20 genes.  Labelling all of them in a force or
# waterfall plot produces overlapping text at print size, so the non-core genes
# are pooled into a single "other genes" term.  The decomposition remains
# EXACTLY additive because the pooled term is the sum of those SHAP values.
others <- setdiff(colnames(S), CORE)
S5 <- cbind(S[, CORE, drop = FALSE], `other` = rowSums(S[, others, drop = FALSE]))
X5 <- cbind(sv$X[, CORE, drop = FALSE], `other` = NA_real_)
stopifnot(max(abs(rowSums(S) - rowSums(S5))) < 1e-10)
sv5 <- shapviz::shapviz(S5, X = X5, baseline = sv$baseline)

relabel <- function(p) {
  p$data$label <- gsub("other\\s*=\\s*NA", paste(length(others), "other genes"),
                       p$data$label)
  for (k in seq_along(p$layers)) {
    if (class(p$layers[[k]]$geom)[1] == "GeomTextRepel") {
      p$layers[[k]]$aes_params$size <- 2.1        # mm -> ~6 pt at print size
      p$layers[[k]]$aes_params$max.overlaps <- Inf
    }
  }
  p
}

# =============================================================================
# 10.  Null-control analyses
# =============================================================================
# These quantify how much of the near-ceiling discrimination is intrinsic to
# tumour-versus-normal classification rather than to the gene set.  They are
# reported in the manuscript and in Supplementary Table S4.
say("STEP 7  null-control analyses")

single_gene_auc <- function(X, grp, genes, n_random = 2000, seed = 123) {
  disc <- function(v) {
    r <- pROC::roc(grp, v, quiet = TRUE)
    max(as.numeric(pROC::auc(r)), 1 - as.numeric(pROC::auc(r)))
  }
  a <- sapply(genes, function(g) disc(X[, g]))
  set.seed(seed)
  keep <- setdiff(colnames(X), genes)
  pool <- sample(keep, min(n_random, length(keep)))
  b <- sapply(pool, function(g) disc(X[, g]))
  list(panel = a, random = b)
}

pc1_auc <- function(X, grp) {
  p <- prcomp(X, center = TRUE, scale. = TRUE)$x[, 1]
  a <- as.numeric(pROC::auc(pROC::roc(grp, p, quiet = TRUE)))
  max(a, 1 - a)
}

panel_df <- train_data[, gene_cols, drop = FALSE]
sg <- single_gene_auc(panel_df, train_data$group, CORE)
write.csv(data.frame(
  set = c(rep("panel_79", length(sg$panel)), rep("random_2000", length(sg$random))),
  auc = c(sg$panel, sg$random)),
  file.path(OUT, "data", "16_auc_selection_bias.csv"), row.names = FALSE)

write.csv(data.frame(
  analysis = c("single_gene_auc_panel_79", "single_gene_auc_random_2000",
               "unsupervised_PC1_classifier"),
  n = c(length(sg$panel), length(sg$random), 1),
  median_auc = c(round(median(sg$panel), 3), round(median(sg$random), 3), NA),
  n_above_0.90 = c(sum(sg$panel >= 0.90), sum(sg$random >= 0.90), NA),
  pc1_auc = c(NA, NA, round(pc1_auc(panel_df, train_data$group), 3))),
  file.path(OUT, "data", "17_null_analysis_summary.csv"), row.names = FALSE)

say("  single-gene AUC: panel median ", round(median(sg$panel), 3),
    " (", sum(sg$panel >= 0.90), "/", length(sg$panel), " >= 0.90)   random median ",
    round(median(sg$random), 3), " (", sum(sg$random >= 0.90), "/",
    length(sg$random), ")")

# =============================================================================
# 11.  Figures
# =============================================================================
say("STEP 8  figures")
IN <- function(cm) cm / 2.54

save_p <- function(p, name, w_cm, h_cm) {
  pdf(file.path(OUT, "figures", paste0(name, ".pdf")), width = IN(w_cm),
      height = IN(h_cm)); print(p); dev.off()
  jpeg(file.path(OUT, "figures", paste0(name, ".jpg")), width = round(IN(w_cm) * DPI),
       height = round(IN(h_cm) * DPI), res = DPI, quality = 100)
  print(p); dev.off()
  say("  saved ", name, "  ", w_cm, " x ", h_cm, " cm")
}

labs <- c("Training","GSE24514","GSE32323","TCGA-CRC","GSE44076","GSE113513")
cf <- colorRamp2(c(0.80, 0.85, 0.90, 0.95, 1.00),
                 c("#2166AC", "#3690C0", "#92C5DE", "#FFFFBF", "#B2182B"))

# ---- 11a  AUC heatmap, top 50 pipelines -------------------------------------
d50  <- head(sel_tab, 50)
cols <- c("train_auc","GSE24514_auc","GSE32323_auc","TCGA_CRC_auc",
          "GSE44076_auc","GSE113513_auc")
mat  <- as.matrix(d50[, cols]); rownames(mat) <- d50$model_name; colnames(mat) <- labs
v    <- rowMeans(mat, na.rm = TRUE)

COHORT_COL <- c("#87CEFA","#2c5292","#90EE90","#e08a3c","#8c5aa8","#3f8f4f")
names(COHORT_COL) <- labs
ta <- HeatmapAnnotation(df = data.frame(Cohort = labs), col = list(Cohort = COHORT_COL),
  show_legend = FALSE, annotation_name_side = "right",
  annotation_name_gp = gpar(fontsize = 8), simple_anno_size = unit(3, "mm"))

ht <- Heatmap(mat, name = "AUC", col = cf, top_annotation = ta,
  cluster_rows = FALSE, cluster_columns = FALSE, show_row_dend = FALSE,
  show_column_dend = FALSE, row_names_side = "left",
  row_names_gp = gpar(fontsize = 6.6), show_column_names = FALSE, border = FALSE,
  width = unit(3.3, "cm"),
  cell_fun = function(j, i, x, y, w, h, fill)
    grid.text(sprintf("%.3f", mat[i, j]), x, y, gp = gpar(fontsize = 6.2)))

right <- rowAnnotation(
  Mean = anno_barplot(v, bar_width = 0.6, gp = gpar(fill = "#99ccf0", col = NA),
    xlim = c(0.5, 1), border = FALSE, width = unit(1.15, "cm"),
    axis_param = list(gp = gpar(fontsize = 6.5), side = "bottom", labels_rot = 0)),
  label = anno_text(sprintf("%.4f", v), location = unit(0.97, "native"),
                    just = "right", gp = gpar(fontsize = 6)), show_legend = FALSE)

lgd_cohort <- Legend(labels = labs, title = "Cohort",
  legend_gp = gpar(fill = COHORT_COL), title_gp = gpar(fontsize = 8),
  labels_gp = gpar(fontsize = 7), grid_height = unit(3, "mm"),
  grid_width = unit(3, "mm"))
lgd_auc <- Legend(col_fun = cf, title = "AUC",
  at = c(0.80, 0.85, 0.90, 0.95, 1.00),
  labels = c("0.8","0.85","0.9","0.95","1.0"), title_gp = gpar(fontsize = 8),
  labels_gp = gpar(fontsize = 7), legend_height = unit(2.8, "cm"),
  grid_width = unit(3.5, "mm"))

drawA <- function() draw(ht + right, show_heatmap_legend = FALSE,
  show_annotation_legend = TRUE, annotation_legend_list = list(lgd_cohort, lgd_auc),
  annotation_legend_side = "right", padding = unit(c(2, 2, 3, 2), "mm"))
pdf(file.path(OUT, "figures", "Fig4a_AUC_heatmap_top50.pdf"),
    width = IN(10.20), height = IN(19.00)); drawA(); dev.off()
jpeg(file.path(OUT, "figures", "Fig4a_AUC_heatmap_top50.jpg"),
     width = round(IN(10.20) * DPI), height = round(IN(19.00) * DPI),
     res = DPI, quality = 100); drawA(); dev.off()
say("  saved Fig4a_AUC_heatmap_top50  10.20 x 19.00 cm")

# ---- 11b  SHAP panels --------------------------------------------------------
th <- theme_bw(base_size = 8) +
  theme(panel.grid.minor = element_blank(),
        plot.title = element_text(size = 8, hjust = 0.5),
        plot.margin = margin(2, 6, 2, 6))

save_p(shapviz::sv_importance(sv, kind = "bar", max_display = 15) + th,
       "Fig4b_SHAP_importance", 6.90, 6.00)
save_p(shapviz::sv_importance(sv, kind = "beeswarm", max_display = 15) + th,
       "Fig4c_SHAP_beeswarm", 6.90, 6.00)
save_p(relabel(shapviz::sv_force(sv5, row_id = crc_s)) + th,
       "Fig4d_SHAP_force", 6.90, 4.98)
save_p(cowplot::plot_grid(
         relabel(shapviz::sv_waterfall(sv5, row_id = crc_s)) + th +
           labs(title = paste("CRC sample", crc_s)),
         relabel(shapviz::sv_waterfall(sv5, row_id = ctl_s)) + th +
           labs(title = paste("Control sample", ctl_s)), ncol = 1),
       "Fig4e_SHAP_waterfall", 6.69, 4.83)
save_p(shapviz::sv_dependence(sv, v = CORE, size = 1.2, alpha = 0.7) + th,
       "FigS_SHAP_dependence", 15.60, 19.51)

# ---- 11c  ROC across the six cohorts -----------------------------------------
roc_df <- do.call(rbind, lapply(c("training", names(COHORTS)), function(cn) {
  dat <- if (cn == "training") train_data else COHORTS[[cn]]
  p   <- predict_model(m_rep, dat[, feats, drop = FALSE])
  r   <- pROC::roc(dat$group, p, quiet = TRUE)
  data.frame(cohort = cn, sens = r$sensitivities, spec = r$specificities)
}))
p_roc <- ggplot(roc_df, aes(1 - spec, sens, colour = cohort)) +
  geom_line(linewidth = 0.6) + geom_abline(lty = 2, colour = "grey60") +
  scale_colour_manual(values = c(Training = "#87CEFA", GSE24514 = "#2c5292",
    GSE32323 = "#90EE90", TCGA_CRC = "#e08a3c", GSE44076 = "#8c5aa8",
    GSE113513 = "#3f8f4f")) +
  labs(x = "1 - specificity", y = "Sensitivity", colour = NULL) +
  coord_equal() + theme_bw(base_size = 8)
save_p(p_roc, "FigS_ROC_six_cohorts", 9.00, 7.50)

# ---- 11d  full 118-pipeline AUC grid -----------------------------------------
res  <- read.csv(file.path(OUT, "data", "03_external_validation_metrics.csv"))
wide <- reshape(res[, c("model_name","cohort","auc")], idvar = "model_name",
                timevar = "cohort", direction = "wide")
M <- as.matrix(wide[, paste0("auc.", c("training", names(COHORTS)))])
rownames(M) <- wide$model_name; colnames(M) <- labs
M <- M[order(-rowMeans(M, na.rm = TRUE)), ]
ht2 <- Heatmap(M, name = "AUC", col = cf, cluster_rows = FALSE,
  cluster_columns = FALSE, row_names_side = "left",
  row_names_gp = gpar(fontsize = 6.2), show_column_names = TRUE,
  column_names_gp = gpar(fontsize = 8), border = FALSE)
pdf(file.path(OUT, "figures", "FigS_AUC_heatmap_all.pdf"),
    width = IN(16.40), height = IN(19.50)); draw(ht2); dev.off()
jpeg(file.path(OUT, "figures", "FigS_AUC_heatmap_all.jpg"),
     width = round(IN(16.40) * DPI), height = round(IN(19.50) * DPI),
     res = DPI, quality = 100); draw(ht2); dev.off()
say("  saved FigS_AUC_heatmap_all  16.40 x 19.50 cm")

# =============================================================================
# 12.  Reproducibility
# =============================================================================
writeLines(capture.output(sessionInfo()), file.path(OUT, "logs", "sessionInfo.txt"))
saveRDS(list(train_data = train_data, COHORTS = COHORTS, gene_cols = gene_cols,
             all_models = all_models, sel_tab = sel_tab),
        file.path(OUT, "data", "checkpoint.rds"))
say("DONE")

# ============================================================
# GSE21510 与 GSE9348 合并、批次校正、差异分析及可视化
# ============================================================

# ---- 加载所需包 ----
library(limma)
library(sva)          # ComBat
library(ggplot2)
library(reshape2)
library(pheatmap)
library(dplyr)
library(tidyr)
library(ggrepel)      # 用于火山图标签

# ---- 设置工作目录 ----
setwd("C:/Users/ASUS/Desktop/7月重头再来")  # 请修改为实际路径

# ============================================================
# 1. 读取数据
# ============================================================

# 读取表达矩阵（假设为CSV，行名=Gene，列名=样本）
expr_GSE21510 <- read.csv("GSE21510_expr.csv", row.names = 1, check.names = FALSE)
expr_GSE9348  <- read.csv("GSE9348_expr.csv",  row.names = 1, check.names = FALSE)

# 读取样本分组信息
meta_GSE21510 <- read.csv("GSE21510_metadata.csv", stringsAsFactors = FALSE)
meta_GSE9348  <- read.csv("GSE9348_metadata.csv",  stringsAsFactors = FALSE)

# ---- 检查数据一致性 ----
# 确保表达矩阵的列名与分组信息的SampleID一致
if (!all(colnames(expr_GSE21510) %in% meta_GSE21510$SampleID)) {
  warning("GSE21510: 表达矩阵列名与分组信息不匹配，请检查")
}
if (!all(colnames(expr_GSE9348) %in% meta_GSE9348$SampleID)) {
  warning("GSE9348: 表达矩阵列名与分组信息不匹配，请检查")
}

# ---- 统一基因名（取两个数据集的交集基因） ----
common_genes <- intersect(rownames(expr_GSE21510), rownames(expr_GSE9348))
cat("共同基因数:", length(common_genes), "\n")

# 提取共同基因
expr_GSE21510 <- expr_GSE21510[common_genes, ]
expr_GSE9348  <- expr_GSE9348[common_genes, ]

# ---- 合并表达矩阵 ----
expr_all <- cbind(expr_GSE21510, expr_GSE9348)

# ---- 合并分组信息 ----
meta_all <- rbind(
  meta_GSE21510,
  meta_GSE9348
)
# 确保顺序与表达矩阵列一致
meta_all <- meta_all[match(colnames(expr_all), meta_all$SampleID), ]

# 检查分组因子
meta_all$Group <- factor(meta_all$Group, levels = c("Control", "CRC"))
table(meta_all$Group)

# ---- 记录批次信息（数据集来源） ----
batch <- c(rep("GSE21510", ncol(expr_GSE21510)), rep("GSE9348", ncol(expr_GSE9348)))
batch <- factor(batch)

# ============================================================
# 2. 批次校正前PCA
# ============================================================

# 转置为样本×基因用于PCA
expr_t <- t(expr_all)
pca_before <- prcomp(expr_t, scale. = TRUE)
pca_df_before <- data.frame(
  PC1 = pca_before$x[,1],
  PC2 = pca_before$x[,2],
  Dataset = batch,
  Group = meta_all$Group
)

p_before <- ggplot(pca_df_before, aes(x = PC1, y = PC2, color = Dataset, shape = Group)) +
  geom_point(size = 3, alpha = 0.7) +
  stat_ellipse(aes(group = Dataset), linetype = 2, level = 0.95) +
  labs(title = "PCA Before Batch Correction",
       x = paste0("PC1 (", round(summary(pca_before)$importance[2,1]*100, 1), "%)"),
       y = paste0("PC2 (", round(summary(pca_before)$importance[2,2]*100, 1), "%)")) +
  theme_minimal(base_size = 14) +
  theme(legend.position = "right")
ggsave("PCA_before_correction.png", p_before, width = 8, height = 6, dpi = 300)
print(p_before)

# ============================================================
# 3. 使用ComBat进行批次校正
# ============================================================

# 确保表达矩阵为数值型
expr_all_matrix <- as.matrix(expr_all)

# ComBat校正（需要model matrix包含生物学变量，这里用分组信息）
mod <- model.matrix(~ Group, data = meta_all)
expr_corrected <- ComBat(dat = expr_all_matrix, batch = batch, mod = mod, par.prior = TRUE)

# 检查校正后数据
cat("校正后表达矩阵维度:", dim(expr_corrected), "\n")

# ============================================================
# 4. 批次校正后PCA
# ============================================================

expr_corrected_t <- t(expr_corrected)
pca_after <- prcomp(expr_corrected_t, scale. = TRUE)
pca_df_after <- data.frame(
  PC1 = pca_after$x[,1],
  PC2 = pca_after$x[,2],
  Dataset = batch,
  Group = meta_all$Group
)

p_after <- ggplot(pca_df_after, aes(x = PC1, y = PC2, color = Dataset, shape = Group)) +
  geom_point(size = 3, alpha = 0.7) +
  stat_ellipse(aes(group = Dataset), linetype = 2, level = 0.95) +
  labs(title = "PCA After Batch Correction (ComBat)",
       x = paste0("PC1 (", round(summary(pca_after)$importance[2,1]*100, 1), "%)"),
       y = paste0("PC2 (", round(summary(pca_after)$importance[2,2]*100, 1), "%)")) +
  theme_minimal(base_size = 14) +
  theme(legend.position = "right")
ggsave("PCA_after_correction.png", p_after, width = 8, height = 6, dpi = 300)
print(p_after)

# ============================================================
# 5. 差异表达分析（使用校正后的数据）
# ============================================================

# 设计矩阵（包含分组信息）
design <- model.matrix(~ Group, data = meta_all)
colnames(design) <- c("Intercept", "GroupCRC")

# 拟合线性模型
fit <- lmFit(expr_corrected, design)
fit <- eBayes(fit)

# 提取差异结果
res <- topTable(fit, coef = "GroupCRC", number = Inf, adjust.method = "BH")
res$Gene <- rownames(res)

# 定义显著阈值
res$Sig <- ifelse(res$adj.P.Val < 0.05 & abs(res$logFC) > 1, 
                  ifelse(res$logFC > 1, "Up", "Down"), 
                  "NotSig")
table(res$Sig)

# ---- 保存完整结果 ----
write.csv(res, "DEA_results_ComBat_corrected.csv", row.names = FALSE)

# ============================================================
# 6. 绘制火山图
# ============================================================

# 准备标记显著基因（只标注top3上下调以保持清晰，可调整）
top_up <- res %>% filter(Sig == "Up") %>% arrange(desc(logFC)) %>% head(3)
top_down <- res %>% filter(Sig == "Down") %>% arrange(logFC) %>% head(3)
label_genes <- rbind(top_up, top_down)

p_volcano <- ggplot(res, aes(x = logFC, y = -log10(adj.P.Val), color = Sig)) +
  geom_point(alpha = 0.6, size = 1.5) +
  scale_color_manual(values = c("Up" = "red", "Down" = "blue", "NotSig" = "gray")) +
  geom_vline(xintercept = c(-1, 1), linetype = "dashed", color = "black", alpha = 0.5) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "black", alpha = 0.5) +
  geom_text_repel(data = label_genes, aes(label = Gene), size = 4, max.overlaps = 10) +
  labs(
    title = "Volcano Plot (GSE21510 + GSE9348 after ComBat)",
    x = "log2 Fold Change",
    y = "-log10(Adjusted P-value)",
    caption = paste0("Up: ", sum(res$Sig == "Up"), ", Down: ", sum(res$Sig == "Down"))
  ) +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none")
ggsave("Volcano_plot.png", p_volcano, width = 8, height = 7, dpi = 300)
print(p_volcano)

# ============================================================
# 7. 提取上调/下调各前20基因并绘制热图
# ============================================================

# 上调前20（按logFC降序）
up_genes <- res %>% filter(Sig == "Up") %>% arrange(desc(logFC)) %>% head(20) %>% pull(Gene)
# 下调前20（按logFC升序）
down_genes <- res %>% filter(Sig == "Down") %>% arrange(logFC) %>% head(20) %>% pull(Gene)

# 合并为40个基因
top40_genes <- c(up_genes, down_genes)
cat("热图基因数:", length(top40_genes), "\n")

# 提取这些基因的表达数据（校正后）
heat_expr <- expr_corrected[top40_genes, ]
# 按logFC排序（上行前20，下行后20）
heat_expr <- heat_expr[top40_genes, ]

# 准备注释信息
annotation_col <- data.frame(
  Dataset = batch,
  Group = meta_all$Group
)
rownames(annotation_col) <- colnames(heat_expr)

# 绘制热图（以Z-score标准化）
pheatmap(heat_expr,
         scale = "row",
         annotation_col = annotation_col,
         show_rownames = TRUE,
         show_colnames = FALSE,
         clustering_distance_rows = "euclidean",
         clustering_distance_cols = "euclidean",
         clustering_method = "complete",
         main = "Top 20 Up & Down Regulated Genes",
         filename = "Heatmap_top40_genes.png",
         width = 10,
         height = 8,
         dpi = 300)

# 同时生成PDF版本（便于编辑）
pheatmap(heat_expr,
         scale = "row",
         annotation_col = annotation_col,
         show_rownames = TRUE,
         show_colnames = FALSE,
         main = "Top 20 Up & Down Regulated Genes",
         filename = "Heatmap_top40_genes.pdf",
         width = 10,
         height = 8)

cat("\n===== 分析完成！生成文件：=====\n")
cat("1. PCA_before_correction.png\n")
cat("2. PCA_after_correction.png\n")
cat("3. DEA_results_ComBat_corrected.csv\n")
cat("4. Volcano_plot.png\n")
cat("5. Heatmap_top40_genes.png / .pdf\n")


# ============================================================
# 6. 绘制火山图（最终版 - 图例颜色正确）
# ============================================================

# ---- 加载所需包 ----
library(ggplot2)
library(ggtext)
library(glue)
library(ggrepel)
library(dplyr)

# ---- 确保 Sig 列按正确顺序设为因子 ----
# 这一步非常关键，保证图例顺序和颜色映射一致
res$Sig <- factor(res$Sig, levels = c("Up", "Down", "NotSig"))

# ---- 准备标记显著基因（各取前5） ----
top_up <- res %>% filter(Sig == "Up") %>% arrange(desc(logFC)) %>% head(5)
top_down <- res %>% filter(Sig == "Down") %>% arrange(logFC) %>% head(5)
label_genes <- rbind(top_up, top_down)

# 统计数量
up_count <- sum(res$Sig == "Up")
down_count <- sum(res$Sig == "Down")

# ---- 绘制火山图 ----
p_volcano <- ggplot(res, aes(x = logFC, y = -log10(adj.P.Val), color = Sig)) +
  geom_point(alpha = 0.6, size = 1.5) +
  
  # 颜色映射：使用命名向量 + 显式 breaks/labels
  scale_color_manual(
    values = c("Up" = "#E41A1C", "Down" = "#377EB8", "NotSig" = "#BEBEBE"),
    breaks = c("Up", "Down", "NotSig"),
    labels = c("Up", "Down", "Not Sig"),
    name = NULL
  ) +
  
  # 图例样式：强制显示为实心圆点
  guides(
    color = guide_legend(
      override.aes = list(
        shape = 19,        # 实心圆
        size = 4,
        alpha = 0.8
      ),
      nrow = 3             # 垂直排列
    )
  ) +
  
  # 阈值线
  geom_vline(xintercept = c(-1, 1), linetype = "dashed", color = "black", alpha = 0.4, linewidth = 0.6) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "black", alpha = 0.4, linewidth = 0.6) +
  
  # X轴刻度：明确显示 -1 和 1
  scale_x_continuous(
    breaks = function(x) {
      breaks <- unique(c(-1, 1))
      if (min(x) < -1) breaks <- c(breaks, floor(min(x)))
      if (max(x) > 1) breaks <- c(breaks, ceiling(max(x)))
      return(sort(unique(breaks)))
    },
    limits = function(x) {
      lower <- min(x, -1, na.rm = TRUE) - 0.5
      upper <- max(x, 1, na.rm = TRUE) + 0.5
      c(lower, upper)
    }
  ) +
  
  # 显著基因标签
  geom_text_repel(
    data = label_genes,
    aes(label = Gene),
    size = 3.5,
    max.overlaps = 15,
    box.padding = 0.5,
    point.padding = 0.3,
    segment.color = "gray50",
    segment.size = 0.3
  ) +
  
  # 标题和副标题（Up/Down 数量着色）
  labs(
    title = "Volcano Plot (GSE21510 + GSE9348 after ComBat)",
    subtitle = glue("<span style='color:#E41A1C;font-weight:bold;'>Up: {up_count}</span>  |  <span style='color:#377EB8;font-weight:bold;'>Down: {down_count}</span>"),
    x = "log2 Fold Change",
    y = "-log10(Adjusted P-value)"
  ) +
  
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 12),
    legend.key = element_blank(),
    legend.spacing.y = unit(0.2, "cm"),
    
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
    plot.subtitle = element_markdown(hjust = 0.5, size = 14, margin = ggplot2::margin(b = 10, unit = "pt")),
    
    axis.title = element_text(face = "bold", size = 13),
    axis.text = element_text(size = 11),
    panel.grid.minor = element_blank()
  )

# ---- 保存 ----
ggsave("Volcano_plot.png", p_volcano, width = 8.5, height = 7.5, dpi = 300)
ggsave("Volcano_plot.pdf", p_volcano, width = 8.5, height = 7.5)

print(p_volcano)
cat("火山图已保存为 PNG 和 PDF 格式\n")

